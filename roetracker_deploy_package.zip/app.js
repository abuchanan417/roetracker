const root = document.getElementById('root');
root.innerHTML = `<div class='p-6'>
  <h1 class='text-2xl font-bold mb-4'>🔍 ROE V4ST Tile Tracker</h1>
  <p>This is your live dashboard. Backend integration pending Firebase setup.</p>
</div>`;